function goBack() {
    this.window.history.back();
}
function goOpen() {
    this.window.location.href = '../admin/houses/index.php';
}
