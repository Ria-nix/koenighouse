<div class="grid_wrap">
    <div class="wrap_nav">
        <img src="../images/Logo.svg" alt="logo" onClick="goHome()">
        <div class="buttons">
            <?php echo $class_btn; ?>
            <!-- <a href="" class="exit">Выйти</a> -->
            <!-- <a href="" class="back_arrow" onClick="goBack()">Назад</a> -->
        </div>
    </div>        
</div>    