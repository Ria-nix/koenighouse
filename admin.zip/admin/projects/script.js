// 'use strict';

/* ---------------------------- open the project ---------------------------- */
// function openProj(){
    // $('.open_btn').each(elem => {
    //     elem.addEventListener()
        console.log(1);
    // })
// }