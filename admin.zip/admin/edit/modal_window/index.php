<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="scss/style.css">
</head>
<body>
    <div class="modal_wrap">
        <div class="modal_img">
            <h4>Маркетинговое Изображение</h4>
            <div class="mod_image">
                <img src="../../images//home.jpg" alt="img">
                <div class="btn_img">                    
                    <span class="remove_btn">Удалить</span>
                    <span class="close_btn">Закрыть</span>
                </div>               
            </div>
        </div>
    </div>
    <div class="content"></div>
    
</body>
</html>